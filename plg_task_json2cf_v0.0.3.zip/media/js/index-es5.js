(function () {
	'use strict';

	console.log('Hello from Json2cf');

})();
